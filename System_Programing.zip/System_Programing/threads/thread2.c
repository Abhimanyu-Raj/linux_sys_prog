#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
int num = 0;
pthread_mutex_t mymutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t mycond = PTHREAD_COND_INITIALIZER;
void *fun1()
{
	printf("In thread 1\n");
	pthread_mutex_lock(&mymutex);
	if(num != 5)
		pthread_cond_wait(&mycond,&mymutex);
	
	printf("Caught the signal\n");
	printf("Turn on cpu fan\n");
	pthread_mutex_unlock(&mymutex);
	pthread_exit(NULL);
}
void *fun2()
{
	printf("In thread 2\n");
	pthread_mutex_lock(&mymutex);
	int i =0;
	for(i=0;i<5;i++)
	{
		num+=1;
		printf("num : %d\n",num);
		if(num == 5)
			pthread_cond_signal(&mycond);

	}
	pthread_mutex_unlock(&mymutex);
	pthread_exit(NULL);
}
int main()
{
	pthread_t tid1,tid2;
	pthread_create(&tid1,NULL,fun1,0);
	pthread_create(&tid2,NULL,fun2,0);
	pthread_join(tid1,0);
	pthread_join(tid2,0);
	pthread_exit(NULL);

}
