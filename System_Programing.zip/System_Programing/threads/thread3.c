#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
void *fun()
{
	printf("in thread 1\n");
	pthread_exit("BYE");

}
int main()
{
	printf("in default thread\n");
	pthread_t mythread;
	int ret = pthread_create(&mythread,NULL,fun,0);
	printf("Exiting default thread\n");
	void *a;
	//pthread_exit(&a);
	
	pthread_join(mythread,&a);
	printf("retun status of thread1 :%s\n",(char *)a);
}
