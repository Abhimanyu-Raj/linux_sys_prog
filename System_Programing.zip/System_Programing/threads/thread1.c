#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<string.h>
struct data
{
	int data;
	char str[5];
};
void *fun(void *a)
{
	printf("In thread1\n");
	printf("message from default thread : %d\n",((struct data *)a)->data);
	printf("message from default thread : %s\n",((struct data *)a)->str);
	pthread_exit(NULL);
}
void *fun1()
{
	printf("In thread2\n");
	pthread_exit(NULL);
}
int main()
{
	struct data m;
	m.data = 10;
	strcpy(m.str,"hai");
	char *str = "hello";
	pthread_t mythread,mythread1;
	pthread_create(&mythread,NULL,fun,(void *)&m);
	pthread_create(&mythread1,NULL,fun1,0);
//	pthread_join(mythread,0);
//	pthread_join(mythread1,0);
	printf("exiting default thread\n");
	pthread_exit(NULL);
}





