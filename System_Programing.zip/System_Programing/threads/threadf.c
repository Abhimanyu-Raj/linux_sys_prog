#include<stdio.h>
#include<pthread.h>
//#include<sys/type.h>
void *thrdfun(void *args)
{
int i;
for(i=0;i<10;i++)
{
printf("i=%d\n",i);
sleep(3);
}

}
int main()
{
pthread_t mythread;
void *thread_result;
pthread_create(&mythread,NULL,thrdfun,NULL);
sleep(1);
return 0;
}
