#include<stdio.h>
#include<pthread.h>
void *fun()
{
printf("wiht fun %x\n",pthread_self());
pthread_exit(NULL);
}
int main()
{
pthread_t mythread;
printf("creating thread\n");
pthread_create(&mythread,NULL,fun,0);
pthread_exit(NULL);
}
