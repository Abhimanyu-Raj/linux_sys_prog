#include<stdio.h>
#include<pthread.h>
//#include<sys/type.h>
void *thrdfun(void *args)
{
int i;
for(i=0;i<25;i++)
{
printf("i=%d\n",i);
sleep(1);
}

}
int main()
{
pthread_t mythread;
void *thread_result;
pthread_create(&mythread,NULL,thrdfun,NULL);
pthread_join(mythread,&thrdfun);
int i;
for(i=0;i<25;i++)
{
sleep(1);
printf("inside i %d\n",i);
}
//sleep(25);
//pthread_join(mythread,&thrdfun);
//int i;
return 0;
}
