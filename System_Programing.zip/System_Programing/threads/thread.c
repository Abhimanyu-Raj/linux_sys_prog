#include<pthread.h>
#include<unistd.h>
#include<stdio.h>
#include<string.h>
struct message
{
	int id;
	char msg[10];
}m;
void *thread1(void *m)
{
	printf("In thread1 : msg = %s : tid %x\n",((struct message *)m)->msg,pthread_self());
	printf("Id = %d\n",((struct message *)m)->id);
//	sleep(2);
	printf("End of thread1\n");
	pthread_exit("Good bye");
}
int main()
{
	printf("In default thread\n");
//	char str[10]="hello";
	m.id=10;
	strcpy(m.msg,"google");
	pthread_t tid1;
	pthread_create(&tid1,NULL,thread1,(void *)&m);
//	sleep(1);
	void *status;
	//char status[15]="";
	pthread_join(tid1,(void **)&status);
	printf("exit status = %s\n",(char *)status);
	printf("End of default thread\n");
	pthread_exit(NULL);
}

