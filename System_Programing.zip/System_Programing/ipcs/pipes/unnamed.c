#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
#include<signal.h>
void handler(int a)
{
	printf("signal no :%d\n",a);
}
int main()
{
	signal(SIGPIPE,handler);
	char data[10]="hello";
	int fd[2];
	int r = pipe(fd);
	if(r==-1)
	{
		perror("pipe creation failed\n");
		exit(1);
	}	
	else
	{
		printf("pipe created successfully\n");
		printf("fd[0] : %d\n,fd[1] : %d\n",fd[0],fd[1]);

//		close(fd[1]);
		int ret = fork();
		if(ret==0)
		{
		printf("In child\n");
		int w = write(fd[1],&data,sizeof(data));				if(w==-1)
			perror("write filed :");					else
			printf("data written successfully\n");
		}
		else
		{
		wait(0);
		printf("In parent\n");
		char buff[10];
		int r = read(fd[0],&buff,sizeof(buff));
		if(r==-1)
			perror("read filed\n");
		else
		{
			buff[r]='\0';
			printf("data read from pipe : %s\n",buff);
		}
		}
	}
}





