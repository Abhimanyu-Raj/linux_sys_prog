#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
//	close(0); 
	int fd = open("pipe",O_RDONLY);
	if(fd == -1)
	{
		perror("open failed :");
		exit(1);
	}
	else
	{
		printf("open successfully : fd :%d\n",fd);
		char buff[10];
		int r = read(fd,buff,sizeof(buff));
                if(r == -1)
                {
                        perror("read failed :");
                        exit(1);
                }
                else
                {	buff[r]='\0';
                        printf("data read successfully : %s\n",buff);
                }
	}
}
