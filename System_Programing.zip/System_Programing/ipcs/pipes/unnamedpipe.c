#include <stdio.h>
#include <unistd.h>	//fork()
#include <fcntl.h>	//read(),write()
#include <stdlib.h>	//wait()
#include <signal.h>	//signal()
void sig_handler(int signo)
{
	printf("Programme received a signal : %d\n",signo);
}
int main()
{	signal(SIGPIPE,sig_handler);
//	close(0);
	int fd[2];
	int ret = pipe(fd);
	if(ret == -1)
	{
		perror("pipe failed :");
		exit(1);
	}
	else
	{
		printf("pipe created successfully\nrfd : fd[0] = %d\n",fd[0]);
		printf("wfd : fd[1] = %d\n",fd[1]);
	//	close(fd[0]);
		int child = fork();
		if(child == 0)
		{
			printf("In child\n");
			int w = write(fd[1],"hello",6);
			if(w == -1)
			{
				perror("write failed :");
				exit(1);
			}
			else	
			{
				printf("data written successfully\n");
			}
		}
		else
		{	wait(NULL);
			printf("In parent\n");
			char buff[10];
			int r = read(fd[0],buff,sizeof(buff));
			if(r == -1)
			{
				perror("read failed :");
				exit(1);
			}
			else
			{	buff[r]='\0';
				printf("data read successfully : %s\n",buff);
			}
		}
	}
}
