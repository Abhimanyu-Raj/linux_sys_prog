#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<signal.h>
void sig_handler(int signo)
{
	printf("signal received : %d\n",signo);
}
int main()
{	signal(SIGPIPE,sig_handler);
	int fd = open("pipe",O_WRONLY|O_CREAT,0666);
	if(fd == -1)
	{
		perror("open failed :");
		exit(1);
	}
	else
	{
		printf("open successfully : fd :%d\n",fd);
		sleep(5);
		int w = write(fd,"google",7);
		if(w == -1)
		{
			perror("write failed :");
			exit(1);
		}
		else
		{
			printf("data written successfully\n");
		}
	}
}
