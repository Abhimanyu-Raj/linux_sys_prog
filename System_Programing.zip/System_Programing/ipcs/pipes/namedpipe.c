#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>
int main()
{
	int p = mkfifo("mypipe1",S_IFIFO|0666);	
	if(p==-1)
		perror("mknod failed :");
	else
		printf("pipe created successfully\n");
	
/*	int fd =  open("mypipe1",O_RDONLY);

	if(fd==-1)
		perror("open  failed :");
	else
		printf("pipe open successfully\n");*/

	char buff1[10];
	int rd = read(p,&buff1,sizeof(buff1));
        if(rd==-1)
                perror("write failed :");
        else
	{
		buff1[rd]='\0';
                printf("data read from pipe :%s\n",buff1);
	}
}




