#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<stdlib.h>

int main()
{
	int p = mkfifo("mypipe1",S_IFIFO|0666);	
	if(p==-1)
		perror("mknod failed :");
	else
		printf("pipe created successfully\n");
	/*
	int fd =  open("mypipe1",O_RDWR);
	if(fd==-1)
		perror("open  failed :");
	else
		printf("pipe open successfully\n");*/
	char buff1[]="cranes varsity";
	int rd = write(p,&buff1,sizeof(buff1));
        if(rd==-1)
                perror("write failed :");
        else
	{
		printf("write sucess\n");
                printf("data read from pipe :%s\n",buff1);
	}
}



