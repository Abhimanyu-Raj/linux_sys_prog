#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
int main()
{
	char buff[10]="hello";
	int fd =  open("mypipe",O_WRONLY|O_CREAT);
        if(fd==-1)
                perror("open  failed :");
        else
                printf("pipe open successfully\n");
	int r = write(fd,&buff,sizeof(buff));
	if(r==-1)
		perror("write failed :");
	else
		printf("data written to pipe succesfully\n");

}
