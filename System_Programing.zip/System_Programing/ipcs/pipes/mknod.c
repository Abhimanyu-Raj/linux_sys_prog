#include<stdio.h>
#include<fcntl.h>	//S_IFIFO
#include<stdlib.h>	//exit	
int main()
{
//	int ret = mknod("pipe4",S_IFIFO | 0666,0);
	int ret = mkfifo("pipe4",S_IFIFO | 0666);
	if(ret == -1)
	{
		perror("Mkfifo failed :");
		exit(1);
	}
	else
	{
		printf("Pipe created successfully\n");
	}
}
