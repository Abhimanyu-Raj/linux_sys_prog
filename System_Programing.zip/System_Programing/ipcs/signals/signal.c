#include<stdio.h>
#include<unistd.h>	//fork()
#include<signal.h>	//signal()
#include<stdlib.h>	//wait()
void sig_handler(int signo)
{
	printf("Programme received a signal : %d\n",signo);
//	exit(1);
}
int main()
{
	signal(SIGCHLD,sig_handler);
	signal(SIGKILL,SIG_IGN);
	//printf("hai\n");
	//int a=10,b=0;
	//printf("a/b = %d\n",a/b);
	int ret = fork();
	if(ret == 0)
	{
		printf("In child\n");
		kill(getppid(),SIGKILL);
		printf("End of child\n");
		exit(0);
	}
	else
	{
//		signal(SIGCHLD,sig_handler);
		wait(NULL);
		//signal(SIGCHLD,sig_handler);
		printf("In parent\n");
		exit(0);
	}
//	printf("end of process\n");
}
