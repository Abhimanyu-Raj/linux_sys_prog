#include<stdio.h>
#include<signal.h>
#include<stdlib.h>
void my(int);
int a=1,b=0;

int main()
{
signal(SIGFPE,my);
a=a/b;
printf("%d",a);
}
void my(int a)
{
printf("signo is %d",a);
exit(0);
}
