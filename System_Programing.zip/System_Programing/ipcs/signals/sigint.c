#include<stdio.h>
#include<signal.h>

//#include<unistd.h>
void my_handler(int signo)
{
printf("signal caught is %d",signo);
}

int main()
{
(void) signal (SIGTSTP , my_handler);//SIGINT SIGQUIT
while(1)
{
printf("hi\n");
sleep(1);
}
}
