#include<stdio.h>
#include<signal.h>
#include<stdlib.h>
void fun(int a)
{
	printf("signo - SIGCHLD:%d\n",a);
	//exit(1);
}
void fun1(int a)
{
	printf("signo - SIGINT :%d\n",a);
	//exit(1);
}
int main()
{
	//signal(SIGFPE,fun);
	//int a=10,b=0;
	//printf("a/b : %d\n",a/b);
	int ret = fork();
	if(ret==0)
	{
		printf("IN child\n");
		kill(getppid(),SIG_IGN);

		printf("after SIGINT\n");
	}
	else
	{
		signal(SIGCHLD,fun);
		signal(SIGINT,SIG_IGN);
		wait(0);
		printf("IN parent\n");
	}
	

}
