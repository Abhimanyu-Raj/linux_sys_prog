#include<stdio.h>
#include<sys/shm.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	printf("pid : %d\n",getpid());
	key_t key = 10;
	int shmid = shmget(key,50,IPC_CREAT|0666);
	if(shmid == -1)
	{
		perror("shmget failed :");
		exit(1);
	}
	else
	{
		printf("shmid : %d\n",shmid);
		int *ptr = shmat(shmid,NULL,0);
		if(ptr)
		{
			////////////////

			strcpy(ptr,"hello");
			printf("ptr : %p\n",ptr);
			int i;
			for(i=0;i<5;i++)
			{
				*ptr = i;
				printf("data from shared memmory : %c\n",*ptr);
				ptr++;
			
			}
			printf("ptr after loop: %s\n",ptr);
			/////////////////

		}
		else
		{
			perror("shmat failed :");
			exit(1);
		}
		shmdt(ptr);
	}
	
}
