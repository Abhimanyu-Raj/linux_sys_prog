#include<stdio.h>
#include<sys/shm.h>
#include<stdlib.h>
int main()
{
	key_t key = 10;
	int shmid = shmget(key,50,IPC_CREAT|0666);
	if(shmid == -1)
	{
		perror("shmget failed :");
		exit(1);
	}
	else
	{
		printf("shmid : %d\n",shmid);
		char *ptr = shmat(shmid,NULL,0);
		if(ptr)
		{
			////////////////

			int i;
			for(i=0;i<5;i++)
			{
				*ptr = i;
				printf("data from shared memmory : %c\n",*ptr);
				ptr++;
			
			}
			/////////////////

			printf("data from shared memmory as string: %s\n",*ptr);

		}
		else
		{
			perror("shmat failed :");
			exit(1);
		}
		shmdt(ptr);
	}
	
}
