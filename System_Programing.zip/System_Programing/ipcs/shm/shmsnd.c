#include<stdio.h>
#include<sys/shm.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	key_t key = 10;
	int shmid = shmget(key,1000,IPC_CREAT | 0666);
	if(shmid == -1)
	{
		perror("shmget failed :");
		exit(1);
	}
	else
	{
		printf("shmid :%d\n",shmid);
		char *ptr = shmat(shmid,NULL,0);	//RDWR
		if(ptr)
		{
			///////////////////
		int i;
			for(i=50;i<55;i++)
			{
				*ptr = i;
				printf("data from shared memory :%d\n",*ptr);
				ptr++;
			}
			strcpy(ptr,"Hello world");
			//////////////////
		}

//		shmdt(ptr);
	}
}
