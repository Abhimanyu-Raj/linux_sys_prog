#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/msg.h>
#include<string.h>
struct data
{
	int mtype;
	char data[20];
}m;
int main()
{
	key_t key = 15;
	int msqid = msgget(key,IPC_CREAT|0666);
	if(msqid==-1)
	{
		perror("msgget failed :");
		exit(1);
	}
	else
	{
		printf("msqid :%d\n",msqid);
		m.mtype = 10;
		strcpy(m.data,"welcome");
		int r = msgrcv(msqid,&m,sizeof(m),30,0);
		if(r==-1)
			perror("msgrcv failed :");
		else
		{
			printf("data rear from queue :%s\n",m.data);
		}

	}
}







