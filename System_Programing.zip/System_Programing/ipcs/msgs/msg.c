#include<stdio.h>
#include<sys/ipc.h>
#include<sys/msg.h>
struct mymess
{
int mess_type;
char mess_data[20];
};
int main()
{
key_t key=6;
int my_id=msgget(key,IPC_CREAT|0666);
if(my_id ==-1)
	perror("error\n");
else
	printf("my id is %d",my_id);
struct mymess m1;
m1.mess_type=10;
strcpy(m1.mess_data,"first data");
msgsnd(my_id,&m1,sizeof(m1.mess_data),IPC_NOWAIT);

m1.mess_type=20;

strcpy(m1.mess_data,"send data");
msgsnd(my_id,&m1,sizeof(m1.mess_data),IPC_NOWAIT);
}
