#include<stdio.h>
#include<unistd.h>
#include<sys/msg.h>
#include<stdlib.h>
#include<string.h>
struct message
{
	int mtype;
	char mtext[10];
}m;
int main()
{	
	key_t key = 30;
	int msqid = msgget(key,IPC_CREAT | 0666);
	if(msqid == -1)
	{
		perror("msgget failed :");
		exit(1);
	}
	else
	{
		printf("msqid : %d\n",msqid);
		m.mtype = 50;
//		strcpy(m.mtext,"micromax");
//		int rcv = msgrcv(msqid,&m,sizeof(m),50,0);	//random,Blocking
//		int rcv = msgrcv(msqid,&m,sizeof(m),1,IPC_NOWAIT);	//random,Non Blocking
		int rcv = msgrcv(msqid,&m,sizeof(m),0,IPC_NOWAIT);	//fifo,Non Blocking
		if(rcv == -1)
		{
			perror("msgrcv failed :");
			exit(1);
		}
		else
		{
			printf("Message received successfully : %s\n",m.mtext);
		}
	}
}
