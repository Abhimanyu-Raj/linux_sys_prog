#include<stdio.h>
#include<sys/msg.h>
#include<stdlib.h>
#include<string.h>
struct data
{
	int mtype;
	char mtext[20];
}m;
int main()
{
	key_t key = 100;
	int msqid = msgget(key,IPC_CREAT|0666);
	if(msqid==-1)
	{
		perror(" msgget failed :");
		exit(1);
	}
	else
	{
		printf("msqid :%d\n",msqid);
//		m.mtype = 50;
//		strcpy(m.mtext,"hello");
		printf("size of message :%d\n",sizeof(m));
		int w = msgsnd(msqid,&m,sizeof(m),0);
		if(w==-1)
		{
			perror("msgsnd failed :");
			exit(1);
		}
		else
		{
			m.mtype = 20;
                	strcpy(m.mtext,"hai");
			msgsnd(msqid,&m,sizeof(m),0);

			m.mtype = 30;
                        strcpy(m.mtext,"google");
                        msgsnd(msqid,&m,sizeof(m),0);
			
			printf("message send successfully\n");
		}
	}
}
