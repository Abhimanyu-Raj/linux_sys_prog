#include<stdio.h>
#include<sys/msg.h>
#include<sys/types.h>
#include<sys/ipc.h>
struct rcm
{
int m_ty;
char m_data[20];

};
int main()
{
key_t key=6;
struct rcm m1;
int my_id=msgget(key,IPC_CREAT|0666);
if(my_id==-1)
	perror(" " );
else
{
	msgrcv(my_id,&m1,sizeof(m1.m_data),0,0);
	printf("recevd mess %s",m1.m_data);
}

}
