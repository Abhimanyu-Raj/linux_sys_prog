#include<stdio.h>
#include<sys/msg.h>
#include<stdlib.h>
#include<string.h>
struct data
{
	int mtype;
	char mtext[20];
}m;
int main()
{
	key_t key = 100;
	int msqid = msgget(key,IPC_CREAT|0666);
	if(msqid==-1)
	{
		perror(" msgget failed :");
		exit(1);
	}
	else
	{
		printf("msqid :%d\n",msqid);
		m.mtype = 50;
		strcpy(m.mtext,"hello");
		int r = msgrcv(msqid,&m,sizeof(m),30,IPC_NOWAIT);
		if(r==-1)
		{
			perror("msgsnd failed :");
			exit(1);
		}
		else
		{
			m.mtext[r]='\0';
		printf("message read from MSQ : %s\n",m.mtext);
		}
	}
}


