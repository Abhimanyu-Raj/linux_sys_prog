#include<stdio.h>
#include<unistd.h>
#include<sys/msg.h>
#include<stdlib.h>
#include<string.h>
struct message
{
	int mtype;
	char mtext[10];
}m;
int main()
{	
	key_t key = 30;
	int msqid = msgget(key,IPC_CREAT | 0600);
	if(msqid == -1)
	{
		perror("msgget failed :");
		exit(1);
	}
	else
	{
		printf("msqid : %d\n",msqid);
		m.mtype = 50;
		strcpy(m.mtext,"Dell");
		int snd = msgsnd(msqid,&m,sizeof(m),0);	//Blocking
		if(snd == -1)
		{
			perror("msgsnd failed :");
			exit(1);
		}
		else
		{
			printf("Message send successfully\n");
		}
	}
}
