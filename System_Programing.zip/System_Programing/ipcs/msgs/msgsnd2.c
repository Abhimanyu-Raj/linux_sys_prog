#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/msg.h>
#include<string.h>
struct data
{
	int mtype;
	char data[20];
}m;
int main()
{
	key_t key = 15;
	int msqid = msgget(key,IPC_CREAT|0666);
	if(msqid==-1)
	{
		perror("msgget failed :");
		exit(1);
	}
	else
	{
		printf("msqid :%d\n",msqid);
		m.mtype = 10;
		strcpy(m.data,"welcome");
		int snd = msgsnd(msqid,&m,sizeof(m),0);
		if(snd==-1)
			perror("msgsnd failed :");
		else
			printf("data1 written successfully\n");
	//////////////////////

		m.mtype = 20;
                strcpy(m.data,"hello");
                snd = msgsnd(msqid,&m,sizeof(m),0);
                if(snd==-1)
                        perror("msgsnd failed :");
                else
                        printf("data2 written successfully\n");
	
	////////////////////
		m.mtype = 30;
                strcpy(m.data,"hai");
                snd = msgsnd(msqid,&m,sizeof(m),0);
                if(snd==-1)
                        perror("msgsnd failed :");
                else
                        printf("data3 written successfully\n");

	
	}
}
