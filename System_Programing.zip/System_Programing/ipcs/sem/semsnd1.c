#include<stdio.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<string.h>
int main()
{
	key_t key = 10;
	int semid = semget(key,1,IPC_CREAT|0666);
	if(semid==-1)
		perror("semget :");
	else
	{
		printf("semid :%d\n",semid);
		int ret = semctl(semid,0,SETVAL,1);
		
		struct sembuf x ={0,-1,0};
		int op = semop(semid,&x,1);
		if(op==-1)
			perror("semop failed :");
		else
		{
			key_t key = 10;
			int shmid = shmget(key,50,IPC_CREAT|0666);
			if(shmid==-1)
				perror("shmget failed :");
			else
			{
				printf("shmid :%d\n",shmid);
				char *ptr = shmat(shmid,NULL,0);
			if(ptr)
			{	
				strcpy(ptr,"hello");
			/*int i;
			for(i=0;i<5;i++)
			{
				*ptr=i;
				//printf("data from shared memmory :%d\n",*ptr);
				ptr++;
			}*/
			}
			else
				perror("shmat failed :");	
		
			shmdt(ptr);
			}
		}
		semctl(semid,0,SETVAL,1);
	}

}
