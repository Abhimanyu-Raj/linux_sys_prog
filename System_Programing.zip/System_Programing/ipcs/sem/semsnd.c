#include<stdio.h>
#include<sys/sem.h>
#include<stdlib.h>
#include<sys/shm.h>
#include<string.h>
int main()
{
	key_t key = 10;
	int semid = semget(key,1,IPC_CREAT | 0666);
	if(semid == -1)
	{
		perror("semget failed :");
		exit(1);
	}
	else
	{
		printf("semid : %d\n",semid);
		int ctl = semctl(semid,0,SETVAL,1);
		if(ctl == -1)
		{
			perror("semctl failed :");
			exit(1);
		}
		else
		{
			printf("Initialized with value 1\n");
			struct sembuf buff={0,-1,SEM_UNDO};
			//struct sembuf buff={0,-1,0};
			int op = semop(semid,&buff,1);
			if(op == -1)
			{
				perror("semop failed :");
				exit(1);
			}
			else	
			{
				printf("accessed successfully\n");
				////////////////////////
				key_t key = 20;
				int shmid = shmget(key,1000,IPC_CREAT | 0666);
				if(shmid == -1)
				{
					perror("shmget failed :");
					exit(1);
				}
				else
				{
					printf("shmid :%d\n",shmid);
					char *ptr = shmat(shmid,NULL,0);	//RDWR
					if(ptr)
					{	printf("shm attached succesfully\n");
						///////////////////
						strcpy(ptr,"Hello world");
						printf("data written successfully\n");
						//////////////////
					}
					printf("Detaching shared memory\n");
					shmdt(ptr);
				}
				////////////////////////
			}
		//	semctl(semid,0,SETVAL,1);
		//	printf("semaphore released \n");
		}
	}
}
