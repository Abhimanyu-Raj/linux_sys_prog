#include<stdio.h>
#include<sys/stat.h>
#include<unistd.h>
#include<sys/types.h>
#include<fcntl.h>
int main()
{
int fd=open("myfil",O_RDONLY);
if(fd==-1)
	perror("eror");
else
{
	link("myfil.txt","hrdlik.txt");

	symlink("myfil.txt","sftlik.txt");
	system("ls -l myfil.txt hrdlik.txt sftlik.txt");
	unlink("hrdlik.txt");
	unlink("sftlik.txt");
}
}
