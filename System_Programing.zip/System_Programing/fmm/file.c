#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<errno.h>
int main()
{
	char data[20]="hello world.";
	int fd=	open("file2.txt",O_CREAT|O_RDWR,0666);
	if(fd==-1)
	{
		printf("open filed error no: %d\n",errno);
		perror("open filed :");
		exit(1);
	}
	else
	{
		printf("file 1 created with fd :%d\n",fd);
		int w = write(fd,&data,sizeof(data));
		if(w==-1)
		{
			perror("write failed :");
			exit(1);
		}
		else
		{
			printf("data written successfully\n");
			char buff1[20];
			int fd1 = open("file2.txt",O_RDONLY,0666);
			if(fd1==-1)
			{
				perror("open1 filed :");
				exit(1);
			}
			else
			{
				int l = lseek(fd1,5,SEEK_SET); 
				int rd = read(fd1,&buff1,sizeof(buff1));
				buff1[rd]='\0';
				printf("data read : %s\n",buff1);
			}
		}
	}
}



