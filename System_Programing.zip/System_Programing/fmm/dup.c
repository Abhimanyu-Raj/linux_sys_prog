#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<fcntl.h>
int main()
{
	int fd = open("test1.txt",O_RDONLY|O_CREAT);
	if(fd == -1)
	{
		perror("open failed :");
		exit(1);
	}
	else
	{
		printf("fd :%d\n",fd);
	}
	close(0);
	int new_fd = dup2(fd,0);
	if(new_fd == -1)
	{
		perror("dup failed :");
		exit(1);
	}
	else
	{
		printf("new fd = %d\n",new_fd);
	}
	char buff[50];
	fgets(buff,50,stdin);
	printf("buff : %s\n",buff);
//	while(1)
	{}
}
