#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
	int fd  = creat("test3.txt",0666);
	int fd1  = creat("test.txt",0666);
	if(fd  == -1)
	{
		perror("creat failed :");
		exit(1);
	}
	else
	{
		printf("file created successfully\n");
	}
	while(1)
	{
	}
}
