#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<stdlib.h>
int main()
{
//	close(2);
	int fd  = open("test1.txt",O_RDWR | O_CREAT ,0666);
	if(fd  == -1)
	{
		perror("open failed :");
		//printf("open failed : ");
		exit(1);
	}
	else
	{
		printf("file open successfully : fd : %d\n",fd);
		char buff[10]="google";
		//int wr = write(fd,"hello",10);
		int wr = write(fd,buff,sizeof(buff));
		if(wr == -1)
		{
			perror("write failed :");
			exit(1);
		}
		else
		{
			printf("data written successfully\n");
		}
		lseek(fd,0,SEEK_SET);
	//	lseek(fd,-7,SEEK_CUR);
		char rbuff[50];
		int rd = read(fd,rbuff,sizeof(rbuff));
		if(rd == -1)
		{
			perror("read failed :");
			exit(1);
		}
		else
		{
			rbuff[rd]='\0';
			printf("data read : %s\n",rbuff);
		}
	}
//	char buff[5];
//	fgets(buff,5,stdin);
//	printf("buff : %s\n",buff);
}
