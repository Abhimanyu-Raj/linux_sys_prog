#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{//dup fd 1
	int fd1=open("dupman",O_RDONLY|O_CREAT,0777);
	int fd2=open("dupman1",O_RDONLY|O_CREAT,0777);
printf("%d %d",fd1,fd2);
	int fd3=dup2(fd1,1);
	int fd4=dup2(fd2,1);
//close(2);
//dup2(fd);
while(1)
{

}
}
