#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
int main()
{//dup fd 1
	int fd=open("dupman",O_RDONLY|O_CREAT,0777);
	printf("%d",fd);
	close(3);
	int r=dup(1);
	printf(" fd %d dup %d ",fd,r);
//	while(1)
	{

	}
}
