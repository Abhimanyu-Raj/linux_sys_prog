#include<stdio.h>
#include<fcntl.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int fd = open("file2",O_RDONLY,0666);
	if(fd==-1)
	{
		perror("open failed \n");
		exit(1);
	}
	else
	{
		printf("fd : %d\n",fd);
	//	close(0);
		int new_fd =dup(fd);
		if(new_fd==-1)
		{
			perror("dup failed :");
			exit(1);
		}
		else
		{
			char buff[20];
			printf("new fd : %d\n",new_fd);
			gets(buff);
			printf("buff : %s\n",buff);
			while(1)
			{
			}
		}
	}
}
