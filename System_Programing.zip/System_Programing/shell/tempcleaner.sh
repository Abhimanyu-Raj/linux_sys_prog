#!/bin/bash

if [ -f /home/varsity/b138WE/script/log.txt ]
then
	date >> /home/varsity/b138WE/script/log.txt
	find /home/varsity/b138WE/script/ -name "*~" >> /home/varsity/b138WE/script/log.txt
	find /home/varsity/b138WE/script/ -name "*~" -delete
else
	touch /home/varsity/b138WE/script/log.txt
	/home/varsity/b138WE/script/tempcleaner.sh
fi	
