
#!/bin/bash


#echo "This is our first script"
: '
pwd
date
'

a=10
echo $a

read -p "Enter your name: " name
echo "name = $name"
