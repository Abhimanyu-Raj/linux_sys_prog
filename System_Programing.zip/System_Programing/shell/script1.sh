#!/bin/bash

date
a=10
b=20
echo "sum = `expr $a + $b`"
