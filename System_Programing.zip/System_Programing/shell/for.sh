#!/bin/bash 

#shabang line
: '
for (( i = 1 ; i < 5 ; i++ ))
do
    echo c style : $i
done
'

for i in 0 1 2 3 4 
do
echo $i
done
