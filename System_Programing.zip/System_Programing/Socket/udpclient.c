#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
int main()
{
	int sfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sfd==-1)
	{
		perror(" socket failed :");
	} 	
	else
	{
		printf("socket created : sfd = %d\n",sfd);
		
		struct sockaddr_in server;
		server.sin_family = AF_INET;
		server.sin_port =htons(8000);
		server.sin_addr.s_addr=inet_addr("127.0.0.1");
 
//		int b = bind(sfd,(struct sockaddr *)&server,sizeof(server));
/*		if(b==-1)
			perror("bind failed :");
		else
*/		{
		char buff[40];
		int len = sizeof(server);
		while(1)
		{
			printf("enter the message to server :\n");
			fgets(buff,40,stdin);
	
	sendto(sfd,buff,sizeof(buff),0,(struct sockaddr *)&server,len);
			printf("waiting for message from server\n");
	int r = recvfrom(sfd,buff,sizeof(buff),0,(struct sockaddr *)&server,&len);
	printf("got connection from server :%s\n",inet_ntoa(server.sin_addr));		buff[r]='\0';
	printf("message received from client : %s\n",buff);
			
		}
		}
	}
}
