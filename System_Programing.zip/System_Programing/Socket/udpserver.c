#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netinet/ip.h>
#include<arpa/inet.h>
int main()
{
	int sfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sfd==-1)
	{
		perror(" socket failed :");
	} 	
	else
	{
		printf("socket created : sfd = %d\n",sfd);
		
		struct sockaddr_in server,client;
		server.sin_family = AF_INET;
		server.sin_port =htons(8000);
		server.sin_addr.s_addr=INADDR_ANY;
 
		int b = bind(sfd,(struct sockaddr *)&server,sizeof(server));
		if(b==-1)
			perror("bind failed :");
		else
		{
		char buff[40];
		int len = sizeof(client);
		while(1)
		{
		printf("waiting for connection:...\n");
		while(1)
		{
			printf("waiting for message from client\n");
		
	int r = recvfrom(sfd,buff,sizeof(buff),0,(struct sockaddr *)&client,&len);
		
		printf("client connected : %s\n",inet_ntoa(client.sin_addr));
		buff[r]='\0';
		printf("Message from client : %s\n",buff);

		printf("enter the messaget to client \n");
		fgets(buff,40,stdin);
		sendto(sfd,buff,sizeof(buff),0,(struct sockaddr *)&client,len);


		}
		}
		}
	}
}
