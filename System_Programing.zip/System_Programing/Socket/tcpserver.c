#include<stdio.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<netinet/in.h>	//sockaddr_in
#include<arpa/inet.h>   //inet_ntoa
int main()
{
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd == -1)
	{
		perror("socket failed :");
		exit(1);
	}
	else
	{
		printf("sfd : %d\n",sfd);
		struct sockaddr_in server,client;
		server.sin_family = AF_INET;
		server.sin_port = htons(8000);
		server.sin_addr.s_addr = INADDR_ANY;
		int b = bind(sfd,(struct sockaddr *)&server,sizeof(server));
		if(b == -1)
		{
			perror("bind failed :");
			exit(1);
		}
		else
		{
			printf("bind successfull\n");
			listen(sfd,10);
			int len = sizeof(client);
		while(1)
		{
			int cfd = accept(sfd,(struct sockaddr *)&client,&len);
			if(cfd == -1)
			{
				perror("accept failed :");
				exit(1);
			}
			else
			{
			int child = fork();
			if(child == 0)	
			{
				printf("client connected ip: %s\n",inet_ntoa(client.sin_addr));
				while(1)
				{
					char buff[50];
					printf("waiting for message from client\n");
					//int rd = recv(cfd,buff,sizeof(buff),0);

		//int rd = recvfrom(cfd,buff,sizeof(buff),0,(struct sockaddr *)&client,&len);
					int rd = read(cfd,buff,sizeof(buff));
					if(rd == -1)
					{
						perror("read failed :");
						exit(1);
					}
					else if(rd == 0)
					{
				printf("client disconnected ip: %s\n",inet_ntoa(client.sin_addr));
					exit(1);
					}
					else
					{
						buff[rd]='\0';
						printf("message from server :%s\n",buff);
					}

					//printf("Enter the message to client\n");
					//fgets(buff,50,stdin);
					write(cfd,buff,sizeof(buff));
		//sendto(cfd,buff,sizeof(buff),0,(struct sockaddr *)&client,sizeof(client));
			
				}				
			}
			}
		}
		}
	}
}








