#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
int main()
{
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	{
		perror(" socket failed :");
	} 	
	else
	{
		printf("socket created : sfd = %d\n",sfd);
		
		struct sockaddr_in server,client;
		server.sin_family = AF_INET;
		server.sin_port =htons(8000);
		server.sin_addr.s_addr=INADDR_ANY;
 
		int b = bind(sfd,(struct sockaddr *)&server,sizeof(server));
		if(b==-1)
			perror("bind failed :");
		else
		{
			int l = listen(sfd,1);
			int len = sizeof(client);
			int cfd = accept(sfd,(struct sockaddr *)&client,&len);
			if(cfd==-1)
				perror("accept failed :");
			else
			{
				printf("cfd : %d\n",cfd);
			char buff[40];
			while(1)
			{
	
				printf("waiting for message from client:..\n");		
				recv(cfd,buff,40,0);
				printf("message from server: %s\n",buff);

				printf("enter the message to Client: \n");
				fgets(buff,40,stdin);
				send(cfd,buff,40,0);


			}

			}
		}
	}
}
