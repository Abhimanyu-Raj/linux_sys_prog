#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdlib.h>
int main()
{
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd == -1)
	{
		perror("socket failed :");
		exit(1);
	}
	else
	{
		printf("sfd :%d\n",sfd);
		struct sockaddr_in server,client;
		server.sin_family = AF_INET;
		server.sin_port = htons(8000);
		server.sin_addr.s_addr = INADDR_ANY;

		int b = bind(sfd,(struct sockaddr *)&server,sizeof(server));
		if(b==-1)
		{
			perror("bind failed");
			exit(1);
		}
		else
		{
			int l = listen(sfd,1);
			if(l==-1)
				perror("listen failed :");
			else
			{
			printf("waiting for clients....\n ");
			int len = sizeof(client);
			int cfd = accept(sfd,(struct sockaddr *)&client,&len);
			if(cfd==-1)
			{
				perror("accept failed :");
				exit(1);
			}
			else
			{
				char buff[40];
		printf("client connected :%s\n",inet_ntoa(client.sin_addr));
				while(1)
				{

				printf("waiting for message from client\n");
                                int r = recv(cfd,buff,40,0);
                                buff[r] = '\0';
                                printf("data received from client: %s\n",buff);
				
				printf("Enter the message to client\n");                                        fgets(buff,40,stdin);
                                send(cfd,buff,40,0);

				}
			}
			}
				
		}
	}
}



