#include<stdio.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<netinet/in.h>	//sockaddr_in
#include<arpa/inet.h>	//inet_addr
int main()
{
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd == -1)
	{
		perror("socket failed :");
		exit(1);
	}
	else
	{
		printf("sfd : %d\n",sfd);
		struct sockaddr_in server;
		server.sin_family = AF_INET;
		server.sin_port = htons(8000);
		server.sin_addr.s_addr = inet_addr("192.168.0.175");
		int c = connect(sfd,(struct sockaddr *)&server,sizeof(server));
		if(c == -1)
		{
			perror("connect failed :");
			exit(1);
		}
		else
		{
			printf("connect successfull\n");
			char buff[50];
			while(1)
			{
				printf("Enter the message to server : \n");
				fgets(buff,50,stdin);
				write(sfd,buff,sizeof(buff));

				printf("waiting for message from server\n");
				//int rd = recv(sfd,buff,sizeof(buff),0);
				int rd = read(sfd,buff,sizeof(buff));
				buff[rd]='\0';
				printf("message from server :%s\n",buff);	


			}
		}
	}
}








