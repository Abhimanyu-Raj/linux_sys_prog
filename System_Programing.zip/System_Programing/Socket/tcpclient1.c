#include<stdio.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdlib.h>

int main()
{
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd == -1)
	{
		perror("Client socket failed :");
		exit(1);
	}
	else
	{
		printf("sfd :%d\n",sfd);
		struct sockaddr_in server;
		server.sin_family = AF_INET;
		server.sin_port = htons(8000);
		server.sin_addr.s_addr = inet_addr("127.0.0.1");
		
		int c = connect(sfd,(struct sockaddr *)&server,sizeof(server));
		if(c==-1)
		{
			perror("connection failed :");
			exit(1);
		}
		else
		{
			printf("connected to server successfully\n");
			char buff[40];
			while(1)
			{
			
				printf("Enter the message to server\n");
				fgets(buff,40,stdin);
				send(sfd,buff,40,0);
				
				printf("waiting for message from server\n");
				int r = recv(sfd,buff,40,0);
				buff[r] = '\0';			
				printf("data received from server: %s\n",buff);
							
			}

		}
	}
}










