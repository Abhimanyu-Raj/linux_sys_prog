#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
#include<stdlib.h>
int main()
{
	printf("helloworld\n");
	printf("pid = %d \n",getpid());
	int ret=fork();
	if(ret)
	{
	printf("in parent %d \n",ret);
	printf("in parent child id %d \n",ret);
	int ret1=wait(0);
	printf("ret1=%d",ret1);
	}
	else
	{
	printf("in child %d\n",getpid());
	printf("in child parent id %d \n",getppid());
	}
}
