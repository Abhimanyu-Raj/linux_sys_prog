#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int a=10;
int main()
{
	int b = 20;
	printf("IN PARENT a :%d b:%d\n",a,b);
	int child1 = vfork();
	if(child1 == 0)
	{
		printf("In child a :%d b:%d\n",a,b);
		a+=10;
		b+=10;
		printf("In child after change a :%d b:%d\n",a,b);
		//sleep(3);
		printf("End of child\n");
		exit(0);
	}
	else
	{
		printf("In parent\n");
		printf("In parent before wait a :%d b:%d\n",a,b);
		int status;
		wait(&status);
		printf("In parent after wait a :%d b:%d\n",a,b);
		printf("exit status of child :%d\n",status >>8);
		printf("End of parent\n");
	}
}
