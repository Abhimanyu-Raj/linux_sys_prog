
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main()
{
printf("helloworld\n");
printf("pid is %d",getppid());
}
