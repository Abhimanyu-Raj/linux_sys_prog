#include<stdio.h>
#include<unistd.h>
int main()
{
	printf("good morning\n");
execl("/bin/ls","ls",NULL);
printf("date is prinited \n");
}
