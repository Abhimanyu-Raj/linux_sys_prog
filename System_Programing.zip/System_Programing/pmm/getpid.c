#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
//#include<fctrl.h>
int main()
{
	printf("helloworld\n");
	printf("in main pid and bfr fork = %d \n",getppid());
	int ret=fork();
	printf("%d\n",ret);;
	if(ret)
	{
	printf("in parent %d \n",ret);
	}
	else
	{
//	printf("in child %d\n",getpid());
//	printf("in child parent id %d \n",getppid());
	}
}
