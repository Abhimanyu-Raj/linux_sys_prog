#include<stdio.h>
#include<unistd.h>
int main()
{
	int ret = fork();
	if(ret==0)
	{
		printf("in child\n");
		//execl("test","test",NULL);
		
		char *arg[]={"ls","-l",NULL};
		execvp("ls",arg);
		
		printf("End of child\n");
	}
	else
	{
		wait(0);
		printf("in Parent\n");
	}

}
