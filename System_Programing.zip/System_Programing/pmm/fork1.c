#include<stdio.h>
#include<unistd.h>
int main()
{
	int ret = fork();
	printf("%d\n",ret);
	if(ret==0)
	{
		printf("in child\n");
		//execl("test","test",NULL);
		printf("End of child %d\n",ret);
	}
/*	else
	{
//		wait(0);
		printf("in Parent\n");
	}*/

}
