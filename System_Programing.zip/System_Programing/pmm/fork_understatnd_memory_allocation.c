#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int a=10;
int main()
{
	
	printf("hello\n");
	printf("in process :pid %d\t ppid%d \t\n",getpid(),getppid());

	int child1 = fork();
	if(child1 ==0 )
	{
		printf("IN child1\n");
		sleep(4);
		printf("a = %d\n",a);
		a=a+5;
		printf("a = %d\n",a);
		printf("in child :pid %d\t ppid%d \t\n",getpid(),getppid());
		
/*		int child2 =fork();
		if(child2==0)
		{
			printf("In child \n");
		}
		else
		{
			sleep(1);
			printf("IN parent\n");
		}
*/		exit(5);
	}
	else
	{
		printf("IN parent\n");
		int b;
		 int child2 =fork();
                if(child2==0)
                {
                        printf("In child2 \n");
			exit(10);
                }
                else
                {
                        sleep(1);
                        printf("IN parent\n");
                }

		//wait(&b);	
		waitpid(child1,&b,0);
		
		//sleep(1);
		printf("status from child :%d\n",b>>8);
		printf("a = %d\n",a);
		printf("in parent :pid %d\t ppid%d \t\n",getpid(),getppid());
	}
}
