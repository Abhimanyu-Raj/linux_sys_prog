#include<stdio.h>
int main()
{
int a=3;
if(a)
	printf("hi");
else
	printf("\nbye\n");
}
