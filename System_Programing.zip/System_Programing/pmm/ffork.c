#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
//#include<fctrl.h>
int main()
{
	printf("helloworld\n");
	printf("in main pid and bfr fork = %d \n",getpid());
	int ret=fork();
	printf("result is %d\n",ret);
	if(ret)
	{
	printf("in parent %d \n",getpid());
	}
	else
	{
	printf("in child %d\n",getpid());
	printf("in child parent id %d \n",getppid());
	}
}
