#include<stdio.h>
#include<stdlib.h>
int main()
{
	printf("hai : pid :%d ppid: %d pgrp:%d\n",getpid(),getppid(),getpgrp());
	int child1 = fork();
	if( child1 == 0)
	{	printf("In child\n");
		int a;
		scanf("%d",&a);
		printf("value of a :%d\n",a);
		//sleep(1);
		printf("child : pid :%d ppid: %d pgrp :%d\n",getpid(),getppid(),getpgrp());
		exit(2);	
	}
	else if (child1 > 0)
	{
		printf("In parent\n");
	//	sleep(7);
		int child2 = fork();
		if(child2 == 0)
		{
			printf("In child2\n");
		}
		else
		{
			printf("IN PARENT\n");
			int status;
			int pid_child = waitpid(child1,&status,0);
			printf("exit status of child :%d : %d\n",pid_child,status>>8);
			printf("Parent : pid :%d ppid: %d\n",getpid(),getppid());
			exit(0);	
		}
	}
	else
	{
		printf("fork failed :");
		perror("fork failed :");
		exit(1);
	}
//	printf("End of process\n");
}



