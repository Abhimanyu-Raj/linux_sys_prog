#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main()
{
	int child1 = fork();
	if(child1 == 0)
	{
		printf("In child\n");
		//execl("/bin/ls","ls","-al","-i",NULL);
		//execl("./test","test",NULL);
		//execlp("date","date",NULL);
		char *args[]={"find","./","-type","f","-name","*.c",NULL};
		//execv("/usr/bin/find",args);
		execvp("find",args);
//		printf("End of child\n");
	}
	else
	{
		printf("In parent\n");
		wait(0);
		printf("End of parent\n");
	}
}
