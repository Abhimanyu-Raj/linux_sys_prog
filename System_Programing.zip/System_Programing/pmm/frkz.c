#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
//#include<fctrl.h>
int main()
{
	printf("helloworld\n");
	printf("in main pid and bfr fork = %d \n",getpid());
	int ret=fork();
//	printf("result is %d\n",ret);
	if(ret)
	{
	sleep(3000);
	}
	else
	{
	sleep(3000);
	}
}
