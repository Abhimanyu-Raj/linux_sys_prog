#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc , char *argv[])
{
printf("PID of current exe2 %d\n",getpid());
char *args[]={"hi","buddies","204","210",NULL};
execv("./e3",args);
printf("back to exe2.c\n");
}

