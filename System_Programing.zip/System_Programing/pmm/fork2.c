#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int a = 10;
int main()
{
	int b=5;
	printf("In process\n");
	int ret = fork();
	if(ret==0)
	{
		printf("In child A =%d\t B=%d\n",a,b);
		a=a+5;
		b=b+5;
		printf("In child A =%d\t B=%d\n",a,b);
	}
	else
	{
		printf("In parent A =%d\t B=%d\n",a,b);
		exit(1);
	}
}
