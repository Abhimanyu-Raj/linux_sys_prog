#include<stdio.h>
int main()
{
fork();
fork();
printf("hello buddies\n");
printf("bye");
}
