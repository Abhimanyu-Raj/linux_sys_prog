#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
int main(int argc,char *argv[])
{
printf("we Are in exe3\n");
printf("hiiii\n");
printf("pid of exe3 %d\n",getpid());
}
